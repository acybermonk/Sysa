param ([string]$SubScriptPath,[string]$GroupFile_SelectedFilePath,[string]$FileName,[string]$Process,[string]$loopOption)


Write-Host "In Sub script $user"