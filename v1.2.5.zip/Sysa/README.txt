Sysa 
:the admin utility
v1.2.5

READ ME

####################################

*how to start/stop a session
------------------------------------
'file' > 'session log'
-this will start a new session log with date time
-if a session has already been started then it will clear and close session log

*how to start a new session
------------------------------------
'file' > 'new session' :: time is done by the minute

*how to clear sections
------------------------------------
'edit' > 'clear...' :: there are different options for clear. even clear log.

*how to import mypack 
------------------------------------
## importing will only be from ~\mypack\pack 
'run' > 'import mypack'

*how to change pack 
------------------------------------
'run' > 'change pack'
-select pack to load from ~\mypack directories
-checks for mypack.in file
-once loaded it is ready to import
^clearPack > removes imported and loaded packs

*about
------------------------------------
'help' > 'about'

*logging has show/hide toggle for log
------------------------------------
click show/hide for the log in bottom right corner

*how to edit imported files
------------------------------------
-choose file from drop down menu
-click import file button :: file is now imported :: line format of file is displayed
-click on the <File Selected> box that changed to imported file

*how to change drive 
------------------------------------
-click drive letter in bottom left corner and follow prompt to change drive letter
-once changed it will close and you can move the utility to a different drive
##it does have built in auto detect for finding the correct drive location if it cannot open correctly. 

*how to unmount utility
------------------------------------
-click drive letter in bottom left 
-when prompted to confirm yes or no, remove the y and type '\unst' without quote and hit enter. 


------------------------------------
------------------------------------
------------------------------------
Coming Soon
------------------------------------
------------------------------------

*how to psexec or psremote
------------------------------------
^to come soon	add pop out for each to run scripts on remote systems
^		script block
